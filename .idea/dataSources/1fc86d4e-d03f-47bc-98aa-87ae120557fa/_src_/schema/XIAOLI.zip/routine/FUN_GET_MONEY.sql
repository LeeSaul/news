CREATE FUNCTION
  fun_get_money(
  customer_id NUMBER
)
  RETURN number
  IS
  c_money customer.customer_money%TYPE;
  BEGIN
    select CUSTOMER_MONEY into c_money from customer where id=customer_id;
    RETURN c_money;
    EXCEPTION
    WHEN NO_DATA_FOUND THEN
    dbms_output.put_line('用户名不存在');
  END fun_get_money;
/
