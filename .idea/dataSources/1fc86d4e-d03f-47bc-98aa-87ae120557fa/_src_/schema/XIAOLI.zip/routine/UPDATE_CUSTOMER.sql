CREATE procedure update_customer(
  c_id NUMBER,
  c_email varchar2,
  c_phone varchar2,
  c_province varchar2
)
  as
  BEGIN
    update customer set customer_email=c_email,
      customer_phone=c_phone WHERE ID=c_id;
    update address set province=c_province where customer_id=c_id;
  END update_customer;
/
