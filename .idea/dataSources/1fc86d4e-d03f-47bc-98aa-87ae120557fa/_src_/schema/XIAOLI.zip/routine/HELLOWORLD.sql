CREATE procedure HelloWorld(p_user_name varchar2)
as
begin dbms_output.put_line('hello'|| p_user_name);
end HelloWorld;
/
