CREATE VIEW CUSTOMER_NAME_VIEW AS select ad.id,customer_name,concat(concat(concat(province,city),county),road) customer_address from customer c,address ad
  where c.ID=ad.customer_id WITH CHECK OPTION
/
