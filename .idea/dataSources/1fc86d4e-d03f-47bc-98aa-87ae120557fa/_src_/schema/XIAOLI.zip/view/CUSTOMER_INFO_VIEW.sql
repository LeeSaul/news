CREATE VIEW CUSTOMER_INFO_VIEW AS select customer_name,login_time,province,city
     from customer c,address ad where c.ID=ad.customer_id with READ ONLY
/
